<?php

 /*Método para listar los contactos del usuario
  * @autor Contact Us
  * @version 2018.0409
  * @since 1.0
  * @param Request $id recibe el id del contacto a listar
  */
	$id_usuario=$_REQUEST['id'];

	$servidor="localhost";
	$usuario="id6823610_agenda";
	$contrasenia="agenda";
	$basedatos="id6823610_db_agenda";

	$conexion =new mysqli($servidor, $usuario, $contrasenia, $basedatos);
	$res=$conexion->query("Select * from contacto where usuario_id_usuario=$id_usuario");
	$datos= array();
	foreach ($res as $row) {
		$datos[]=$row;
	}
	
	echo json_encode(utf8ize($datos));
	$conexion->close();

	function utf8ize($d) {
	    if (is_array($d)) {
	        foreach ($d as $k => $v) {
	            $d[$k] = utf8ize($v);
	        }
	    } else if (is_string ($d)) {
	        return utf8_encode($d);
	    }
	    return $d;
	}

?>
