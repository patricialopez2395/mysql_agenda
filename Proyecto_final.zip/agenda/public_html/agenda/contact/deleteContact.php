<?php
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 /*Método para eliminar un contacto
  * @autor Contact Us
  * @version 2018.0409
  * @since 1.0
  * @param Request $id recibe el id del contacto a eliminar
  */
	$servidor="localhost";
	$usuario="id6823610_agenda";
	$contrasenia="agenda";
	$basedatos="id6823610_db_agenda";
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
	$id=$_REQUEST['id'];
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	$conexion =new mysqli($servidor, $usuario, $contrasenia, $basedatos);
	if ($conexion->query("Delete from contacto where id_contacto=$id")===TRUE)
	{
		$conexion->query("Delete from grupo_contacto where id_contacto=$id");
	}
	else
	{
		echo "Error al eliminar el contacto";
	}

	$conexion->close();
?>
