<?php
 /*Método para listar contactos del usuario por grupos
  * @autor Contact Us
  * @version 2018.0409
  * @since 1.0
  * @param Request $id recibe el id del contacto a listar
  */
	$id=$_REQUEST['id'];

	$servidor="localhost";
	$usuario="id6823610_agenda";
	$contrasenia="agenda";
	$basedatos="id6823610_db_agenda";

	$conexion =new mysqli($servidor, $usuario, $contrasenia, $basedatos);
	$res=$conexion->query("Select * from grupo_contacto where id_contacto=$id");
	$datos= array();
	foreach ($res as $row) {
		$datos[]=$row;
	}
	echo json_encode($datos);
	$conexion->close();
?>
