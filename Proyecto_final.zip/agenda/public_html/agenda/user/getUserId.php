<?php
/**
 * Metodo para obtener los datos de usuario.
 * Extiende de la clave AppCompatActivity
 * @author Contact Us
 * @version 2018.04.09
 * @since 1.0
 * @param Request $id recibe el id del usuario que ya esta logueado
 * @return $d retorna el id del usuario consultado
 */
	$id=$_REQUEST['id'];

	$servidor="localhost";
	$usuario="id6823610_agenda";
	$contrasenia="agenda";
	$basedatos="id6823610_db_agenda";

	$conexion =new mysqli($servidor, $usuario, $contrasenia, $basedatos);
	$res=$conexion->query("Select * from usuario where id_usuario=$id");
	$datos= array();
	foreach ($res as $row) {
		$datos[]=$row;
	}
	echo json_encode( utf8ize($datos));
	$conexion->close();

	function utf8ize($d) {
	    if (is_array($d)) {
	        foreach ($d as $k => $v) {
	            $d[$k] = utf8ize($v);
	        }
	    } else if (is_string ($d)) {
	        return utf8_encode($d);
	    }
	    return $d;
	}
?>
