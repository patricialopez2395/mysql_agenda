<?php
/**
 * Metodo para actualizar los datos de usuario.
 * Extiende de la clave AppCompatActivity
 * @author Contact Us
 * @version 2018.04.09
 * @since 1.0
 * @param Request $id recibe el id del usuario que se va a actualizar
 * @param Request $nombre recibe el nombre del usuario que se va a actualizar
 * @param Request $apellido recibe el apellido del usuario que se va a actualizar
 * @param Request $email recibe el correo del usuario que se va a actualizar
 * @param Request $clave recibe la clave del usuario que se va a actualizar
 */
	$id=$_REQUEST['id'];
	$nombre=$_REQUEST['nombre'];
	$apellido=$_REQUEST['apellido'];
	$clave = $_REQUEST['clave'];
	$email=$_REQUEST['email'];

	$servidor="localhost";
	$usuario="id6823610_agenda";
	$contrasenia="agenda";
	$basedatos="id6823610_db_agenda";

	$longitud_clave = strlen($clave);
	$query="";
	if ($longitud_clave>=32) {
		$query="Update usuario set nombre='$nombre', apellido='$apellido', correo='$email' where id_usuario=$id";
	}
	else
	{
		$query="Update usuario set nombre='$nombre', apellido='$apellido', clave=MD5('$clave'), correo='$email' where id_usuario=$id";
	}
	$conexion =new mysqli($servidor, $usuario, $contrasenia, $basedatos);
	if ($conexion->query($query)===TRUE) 
	{
	 	echo json_encode(1);
	}
	 else
	{
		echo json_encode(0);
	}
	
	$conexion->close();
?>
