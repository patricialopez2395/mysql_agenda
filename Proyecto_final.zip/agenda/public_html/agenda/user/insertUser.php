<?php
/**
 * Metodo para insertar los datos de usuario.
 * Extiende de la clave AppCompatActivity
 * @author Contact Us
 * @version 2018.04.09
 * @since 1.0
 * @param Request $nombre recibe el nombre del usuario que se va a registrar
 * @param Request $apellido recibe el apellido del usuario que se va a registrar
 * @param Request $correo recibe el correo del usuario que se va a registrar
 * @param Request $clave recibe la clave del usuario que se va a registrar
 */
	//datos a guardar
	$nombre=$_REQUEST['nombre'];
	$apellido=$_REQUEST['apellido'];
	$clave=$_REQUEST['clave'];
	$correo=$_REQUEST['email'];
	//conexion
	$servidor="localhost";
	$usuario="id6823610_agenda";
	$contrasenia="agenda";
	$basedatos="id6823610_db_agenda";

	$conexion = mysqli_connect($servidor, $usuario, $contrasenia, $basedatos);

	//chequeo de la conexion
	if ($conexion->connect_error) {
    	die("Connection failed: " . mysqli_connect_error());
	} 

	$sql="Insert into usuario (nombre, apellido, clave, correo) values ('$nombre', '$apellido', MD5('$clave'), '$correo')";
	if (mysqli_query($conexion, $sql)) {
		echo json_encode(1);
	}
	else
	{
		echo json_encode(0);
	}
	mysqli_close($conexion);
?>
