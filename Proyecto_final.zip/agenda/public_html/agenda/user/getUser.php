<?php
/**
 * Metodo para buscar los datos de usuario.
 * Extiende de la clave AppCompatActivity
 * @author Contact Us
 * @version 2018.04.09
 * @since 1.0
 * @param Request $email recibe el correo del usuario que se desea consultar
 * @param Request $clave recibe la clave del usuario que se desea consultar
 * @ return $d retorna los datos del usuario 
 */
	$email=$_REQUEST['email'];
	$clave=$_REQUEST['clave'];

	$servidor="localhost";
	$usuario="id6823610_agenda";
	$contrasenia="agenda";
	$basedatos="id6823610_db_agenda";

	$conexion =new mysqli($servidor, $usuario, $contrasenia, $basedatos);
	$res = $conexion->query("Select * from usuario where correo='$email' and clave=md5('$clave')");
	$datos= array();
	foreach ($res as $row) {
		$datos[]=$row;
	}
	echo json_encode(utf8ize($datos));
	$conexion->close();

	function utf8ize($d) {
	    if (is_array($d)) {
	        foreach ($d as $k => $v) {
	            $d[$k] = utf8ize($v);
	        }
	    } else if (is_string ($d)) {
	        return utf8_encode($d);
	    }
	    return $d;
	}
?>
