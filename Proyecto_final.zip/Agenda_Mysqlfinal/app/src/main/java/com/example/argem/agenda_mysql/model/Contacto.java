package com.example.argem.agenda_mysql.model;

import java.util.ArrayList;

/**
 * Clase de los datos a gestionar de Contacto
 * @author Contact Us
 * @version 2018.04.09
 * @since 1.0
 */

public class Contacto {
    //Variable de tipo Entero para guardar el id de contacto
    private int id_contacto;
    //Variable de tipo Cadena para guardar el nombre de contacto.
    private String nombre;
    //Variable de tipo Cadena para guardar el teléfono de contacto.
    private String telefono;
    //Variable de tipo Cadena para guardar la dirección de contacto.
    private String direccion;
    //Variable de tipo Cadena para guardar el alias de contacto.
    private String alias;
    //Variable de tipo Usuario para guardar el objeto usuario.
    private Usuario usuario;
    //Variable de tipo Imagen para guardar el objeto de la imagen de contacto.
    private Imagen imagen;
    //Variable de tipo ArrayList para guardar una lista de grupos.
    private ArrayList<Grupo> lstGrupo;
    //Variable de tipo ArrayList para guardar una lista de contactos.
    private ArrayList<Contacto> lista;

    @Override
    public String toString() {
        return this.nombre + "\n"+this.telefono;
    }
    public int getId_contacto() {
        return id_contacto;
    }

    public void setId_contacto(int id_contacto) {
        this.id_contacto = id_contacto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public ArrayList<Contacto> getLista() {
        return lista;
    }

    public void setLista(ArrayList<Contacto> lista) {
        this.lista = lista;
    }

    public ArrayList<Grupo> getLstGrupo() {
        return lstGrupo;
    }

    public void setLstGrupo(ArrayList<Grupo> lstGrupo) {
        this.lstGrupo = lstGrupo;
    }

    public Imagen getImagen() {
        return imagen;
    }

    public void setImagen(Imagen imagen) {
        this.imagen = imagen;
    }
}
