package com.example.argem.agenda_mysql.model;

/**
 * Clase de los datos a gestionar de Grupos
 * @author Contact Us
 * @version 2018.04.09
 * @since 1.0
 */
public class Grupo {

    //Variable de tipo Entero para guardar el id del grupo
    private int id_grupo;
    //Variable de tipo Cadena para guardar el nombre del grupo.
    private String nombre;

    public int getId_grupo() {
        return id_grupo;
    }

    public void setId_grupo(int id_grupo) {
        this.id_grupo = id_grupo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
