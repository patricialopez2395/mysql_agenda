package com.example.argem.agenda_mysql.model;

/**
 * Clase de los datos a gestionar un Usuario
 * @author Contact Us
 * @version 2018.04.09
 * @since 1.0
 */
public class Usuario {
    //Variable de tipo Entero para guardar el id del usuario.
    private int id_usuario;
    //Variable de tipo Cadena para guardar el nombre de usuario.
    private String nombre;
    //Variable de tipo Cadena para guardar el apellido de usuario.
    private String apellido;
    //Variable de tipo Cadena para guardar la clave de usuario.
    private String clave;
    //Variable de tipo Cadena para guardar el correo de usuario.
    private String correo;

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }
}
