package com.example.argem.agenda_mysql.model;

/**
 * Clase de los datos a gestionar la Imagen
 * @author Contact Us
 * @version 2018.04.09
 * @since 1.0
 */

public class Imagen {

    //Variable de tipo Entero para guardar el id de imagen
    private int id_imagen;
    //Variable de tipo Byte para guardar la imagen
    private byte[] imagen;
    //Variable de tipo Cadena para guardar un comentario de la imagen.
    private String comentario;
    //Variable de tipo Contacto para guardar el id de contacto.
    private Contacto contacto;

    public int getId_imagen() {
        return id_imagen;
    }

    public void setId_imagen(int id_imagen) {
        this.id_imagen = id_imagen;
    }

    public byte[] getImagen() {
        return imagen;
    }

    public void setImagen(byte[] imagen) {
        this.imagen = imagen;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public Contacto getContacto() {
        return contacto;
    }

    public void setContacto(Contacto contacto) {
        this.contacto = contacto;
    }
}
