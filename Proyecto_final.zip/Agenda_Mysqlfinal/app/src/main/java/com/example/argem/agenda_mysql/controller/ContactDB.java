package com.example.argem.agenda_mysql.controller;

import com.example.argem.agenda_mysql.Conexion;
import com.example.argem.agenda_mysql.model.Contacto;
import com.example.argem.agenda_mysql.model.Grupo;
import com.example.argem.agenda_mysql.model.Imagen;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

/**
 * @autor Contact Us
 * @version 2018.0409
 * @since 1.0
 */


public class ContactDB {


    /**
     * Variable privada de tipo Contacto que guardara la información de un contacto.
     */

    private Contacto contacto;

    public Contacto getContacto() {
        if (contacto==null)
        {
            contacto = new Contacto();
        }
        return contacto;
    }
    public void setContacto(Contacto contacto) {
        this.contacto = contacto;
    }

    /**
     * Variable privada de tipo Imagen que guardara la imagen de un contacto.
     */
    private Imagen imagen;

    public Imagen getImagen() {
        if (imagen==null)
        {
            imagen = new Imagen();
        }
        return imagen;
    }
    public void setImagen(Imagen imagen) {
        this.imagen = imagen;
    }
    /**
     * Variable privada de tipo ArrayLit<Grupo> que guardara un listado de grupos que pondran ser asignados los contactos.
     */
    private Grupo grupo;

    private ArrayList<Grupo> lstGrupo;

    public ArrayList<Grupo> getLstGrupo() {
        if (lstGrupo==null)
        {
            lstGrupo = new ArrayList<>();
        }
        return lstGrupo;
    }

    public void setLstGrupo(ArrayList<Grupo> lstGrupo) {
        this.lstGrupo = lstGrupo;
    }

    public Grupo getGrupo() {
        if (grupo==null)
        {
            grupo = new Grupo();
        }
        return grupo;
    }

    public void setGrupo(Grupo grupo) {
        this.grupo = grupo;
    }
}
