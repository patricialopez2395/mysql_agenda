package com.example.argem.agenda_mysql;

/**
 * Clase para conectar el servicio web con la aplicación.
 * @author Contact Us
 * @version 2018.04.09
 * @since 1.0
 */
public class Conexion {
    public static String url="http://flvpmjjd23061995.000webhostapp.com/agenda/";
}
