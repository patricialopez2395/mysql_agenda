package com.example.argem.agenda_mysql.controller;

import android.app.AlertDialog;
import android.content.Context;
import android.os.AsyncTask;

import com.example.argem.agenda_mysql.Conexion;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

/**
 * Esta clase extiende de AsyncTask que nos sirve para trabajar con hilos
 * y tambien sirve para conectarse con los servicios web.
 *
 * @autor Contact Us
 * @version 2018.0409
 * @since 1.0
 */


public class ControllerContact extends AsyncTask<String, Void, String> {

    //Variable de tipo Context que guarda el contexto del contacto
    Context context;

    public ControllerContact(Context ctx)
    {
        context=ctx;
    }

    /**
     * Método para comporbar si hay respuesta del servidor o esta desconectado.
     * @param url Recibe la url del servidor
     * @return Este método devuelve la respuesta del servidor
     */

    private String consultaServidor(String url)
    {
        try {
            URL url_login = new URL(url);
            HttpURLConnection urlConnection = (HttpURLConnection) url_login.openConnection();
            urlConnection.setRequestMethod("POST");

            int rta = urlConnection.getResponseCode();
            StringBuilder result = new StringBuilder();
            String line;

            if (rta == HttpURLConnection.HTTP_OK) {
                InputStream inputStream = urlConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                while ((line = bufferedReader.readLine()) != null) {
                    result.append(line);
                }
                bufferedReader.close();
                inputStream.close();
                urlConnection.disconnect();
                return result.toString();
            } else
                return null;
        } catch (MalformedURLException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Método para interactuar con el servidor web para elejir que accción se va a realizar.
     * @param voids no recibe parametros, ya que son extraidos de otra clase.
     * @return la url combinada con la acción a realizarse en la aplicación para saber si esta activo o fuera de linea.
     */

    @Override
    protected String doInBackground(String... voids) {

        // c lista de contactos de usuario
        if (voids[0].equals("c")) {
            String url = Conexion.url + "contact/listContact.php?id="+voids[1];
            return consultaServidor(url);
        }
        else
        {
            //i imagen del contacto
            if (voids[0].equals("i"))
            {
                String url = Conexion.url+"contact/getImage.php?id=" + voids[1];
                return  consultaServidor(url);
            }
            else
            {
                //g lista del grupo
                if (voids[0].equalsIgnoreCase("g"))
                {
                    String url = Conexion.url + "contact/listGroup.php?id=" + voids[1];
                    return consultaServidor(url);
                }
                else
                {
                    // d eliminar contacto
                    String url = Conexion.url + "contact/deleteContact.php?id=" + voids[1];
                    return consultaServidor(url);
                }
            }
        }
    }
}
