package com.example.argem.agenda_mysql.controller;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;

import com.example.argem.agenda_mysql.Conexion;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Esta clase extiende de AsyncTask que nos sirve para trabajar con hilos
 * y tambien sirve para conectarse con los servicios web.
 *
 * @autor Contact Us
 * @version 2018.0409
 * @since 1.0
 */

public class ControllerImagen extends AsyncTask<Void, Void, Bitmap> {

    // Variable de tipo Entero que guarda el id del contacto para encontar su imagen
    private int id_contacto;

    /**
     * Método para relacionar el id del contacto con su imagen
     * @param id_contacto recibe como parametro el id del contacto para buscar su imagen
     */
    public ControllerImagen(int id_contacto)
    {
        this.id_contacto=id_contacto;
    }

    /**
     * Método para poder trabajar con las imagenes
     * @param strings recibe la ruta de la imagen
     * @return la ruta decodificada de la imagen
     */
    @Override
    protected Bitmap doInBackground(Void... strings) {
        try {
            URL url = new URL(Conexion.url+"upload/"+id_contacto+".jpg");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap myBitmap = BitmapFactory.decodeStream(input);
            return myBitmap;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
}
